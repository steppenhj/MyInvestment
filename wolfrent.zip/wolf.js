document.getElementById("booking-form").addEventListener("submit", function (event) {
    event.preventDefault();
    alert("예약이 완료되었습니다!");
});
